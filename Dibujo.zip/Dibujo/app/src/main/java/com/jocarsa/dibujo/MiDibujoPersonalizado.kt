package com.jocarsa.dibujo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.SurfaceHolder
import android.view.SurfaceView

class MiDibujoPersonalizado(context: Context, attrs: AttributeSet? = null) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    // Paint para figuras rojas
    private val pinturaroja = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }
    // Paint para figuras verdes
    private val pinturaverde = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }
    // Nuevo Paint para dibujar en azul
    private val pinturazul = Paint().apply {
        color = Color.BLUE
        style = Paint.Style.STROKE
        strokeWidth = 8f
    }

    init {
        // Configurar el SurfaceHolder
        holder.addCallback(this)
    }

    // Se ejecuta al crearse el SurfaceView
    override fun surfaceCreated(holder: SurfaceHolder) {
        val canvas = holder.lockCanvas()
        canvas?.let {
            drawShapes(it)
            holder.unlockCanvasAndPost(it)
        }
    }

    // Función para dibujar todas las figuras
    private fun drawShapes(canvas: Canvas) {
        canvas.drawColor(Color.BLACK) // Fondo negro

        // Figuras de prueba en rojo y verde
        canvas.drawCircle(width / 2f, height / 2f, 150f, pinturaroja)
        canvas.drawCircle(50f, 50f, 50f, pinturaroja)
        canvas.drawRect(100f, 100f, 300f, 300f, pinturaroja)
        canvas.drawLine(50f, 400f, 800f, 600f, pinturaverde)
        canvas.drawText("Hola", 200f, 200f, pinturaroja)

        // Dibujar la palabra "HOLA" en azul utilizando líneas y círculos
        drawHola(canvas)
    }

    // Dibuja "HOLA" con líneas y círculos en azul
    private fun drawHola(canvas: Canvas) {
        // Coordenadas y dimensiones básicas
        val startX = 50f
        val startY = 500f
        val letterWidth = 100f
        val letterHeight = 150f
        val gap = 20f

        // Letra H: dos líneas verticales y una horizontal en el centro
        canvas.drawLine(startX, startY, startX, startY + letterHeight, pinturazul)
        canvas.drawLine(startX + letterWidth, startY, startX + letterWidth, startY + letterHeight, pinturazul)
        canvas.drawLine(startX, startY + letterHeight / 2, startX + letterWidth, startY + letterHeight / 2, pinturazul)

        // Letra O: se dibuja como un círculo
        val oCenterX = startX + letterWidth + gap + letterWidth / 2
        val oCenterY = startY + letterHeight / 2
        val oRadius = letterWidth / 2
        canvas.drawCircle(oCenterX, oCenterY, oRadius, pinturazul)

        // Letra L: una línea vertical y otra horizontal en la base
        val lStartX = oCenterX + letterWidth / 2 + gap
        canvas.drawLine(lStartX, startY, lStartX, startY + letterHeight, pinturazul)
        canvas.drawLine(lStartX, startY + letterHeight, lStartX + letterWidth, startY + letterHeight, pinturazul)

        // Letra A: dos líneas diagonales y una línea horizontal en el centro
        val aStartX = lStartX + letterWidth + gap
        val leftBottomA = Pair(aStartX, startY + letterHeight)
        val rightBottomA = Pair(aStartX + letterWidth, startY + letterHeight)
        val topA = Pair(aStartX + letterWidth / 2, startY)
        canvas.drawLine(leftBottomA.first, leftBottomA.second, topA.first, topA.second, pinturazul)
        canvas.drawLine(rightBottomA.first, rightBottomA.second, topA.first, topA.second, pinturazul)
        // Línea horizontal en el centro de la A
        canvas.drawLine(aStartX + letterWidth / 4, startY + letterHeight / 2,
            aStartX + 3 * letterWidth / 4, startY + letterHeight / 2, pinturazul)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {}
}
